Don't change/move the folder Scripts!
Launch X3dToX3dom.jar, insert the file names and press ok!