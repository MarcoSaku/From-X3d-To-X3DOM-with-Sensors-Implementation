/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package X3dToX3dom;

import java.io.IOException;

/**
 *
 * @author MarcoSaku
 */
public class X3dToX3dom {
      public static void main(String[] args) throws IOException, CloneNotSupportedException {
        GUI gui=new GUI();
        gui.startGUI();
              
    }    
    
}
